"""Command-line interface for Fantasy Formula."""

from .main import main

__all__ = ["main"]